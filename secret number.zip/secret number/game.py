import random
memory = random.randint(1000, 9999)
print('bem vindo, adivinhe o numero, boa sorte')
print('')
n1 = int(input('> '))
if n1 == memory:
    print('você acertou')
else:
    print('você errou')
