do you want use a my game? i have a tutorial for you
1: intall python in python.org
2: open the idle
3: click the button "new file" in the button "file"
4: click in the button "file" and click in the button "open"
5: select the "game.py"
6: click in the button "run" and click in the button "run module"
